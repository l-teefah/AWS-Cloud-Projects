<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sewing Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Welcome to the Sewing Website</h1>
    </header>
    <main>
        <p>Explore sewing patterns, tips, and more!</p>
        <img src="images/sewing.jpg" alt="Sewing image" />
    </main>
    <footer>
        <p>&copy; 2024 Sewing Website. All rights reserved.</p>
    </footer>
</body>
</html>
